$(function() {
	$(window).load(function() {
		var name = $(".storeName").text();
		var url = "http://maps.google.com/maps?q=" + name;

		$("#mapUrl").attr("href", url);
	});
});


/* category */
function callApi(category) {
	if (category == "RSFST18007") {
		return "パン屋・サンドイッチ";
	} else if (category == "RSFST18005") {
		return "ケーキ屋・スイーツ";
	} else if (category == "RSFST18015") {
		return "クレープ";
	} else if (category == "RSFST18003") {
		return "甘味処";
	}
}